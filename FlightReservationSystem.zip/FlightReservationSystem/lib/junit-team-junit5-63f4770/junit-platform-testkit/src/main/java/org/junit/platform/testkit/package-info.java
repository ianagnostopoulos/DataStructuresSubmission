/**
 * Test Kit for the JUnit Platform.
 */

package org.junit.platform.testkit;
