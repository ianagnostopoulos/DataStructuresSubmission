/**
 * Tooling support helper.
 *
 * @since 1.3
 */

package platform.tooling.support;
