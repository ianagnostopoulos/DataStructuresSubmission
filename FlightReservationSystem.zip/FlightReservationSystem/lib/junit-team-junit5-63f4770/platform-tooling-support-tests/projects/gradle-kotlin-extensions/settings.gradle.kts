rootProject.name = "gradle-kotlin-extensions"
