rootProject.name = "gradle-starter"
