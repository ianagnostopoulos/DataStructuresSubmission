package foo.bar;

public class FooBar {}
