package foo;

public class Foo {}
