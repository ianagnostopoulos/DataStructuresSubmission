open module foo.bar {
  requires foo;
}
