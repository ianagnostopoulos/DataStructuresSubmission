module foo {
  exports foo;
}
